<?php
include "continue/server/dbConnect.php";

  function decrypt($string,$decryption_key){
    $ciphering = "AES-128-CTR";

    $iv_length = openssl_cipher_iv_length($ciphering);
    $options = 0;

    $decryption_iv = '1234567891011121';

   $decryption=openssl_decrypt ($string, $ciphering,
        $decryption_key, $options, $decryption_iv);
return $decryption;

}
if(isset($_GET['action'])&&isset($_GET['redirect'])&&isset($_GET['clientId'])&&isset($_GET['key'])){
    if (strip_tags($_GET['action'])=="login"){
        $_GET['clientId'] = decrypt($_GET['clientId'],$_GET['key']);
        $redirect= strip_tags($_GET['redirect']);
        $clientId = strip_tags($_GET['clientId']);
        $query = "SELECT * FROM `clients` WHERE `uniqueId` = '".$clientId."'";
        $results = mysqli_query($db, $query);
        $results = mysqli_fetch_assoc($results);
        if ($results['uniqueId'] == $clientId) {
                echo '<script>window.location.href="continue/login.php?url='.strip_tags($_GET['redirect']).'&clientId='.strip_tags($_GET['clientId']).'&name='.strip_tags($results['name']).'#hasPassword";</script>';

            
        }else{
            header("Location:".$redirect);
        }
        }else{
                 $_GET['clientId'] = decrypt($_GET['clientId'],$_GET['key']);
        $redirect= strip_tags($_GET['redirect']);
        $clientId = strip_tags($_GET['clientId']);
        $query = "SELECT * FROM `clients` WHERE `uniqueId` = '".$clientId."'";
        $results = mysqli_query($db, $query);
        $results = mysqli_fetch_assoc($results);
        if ($results['uniqueId'] == $clientId) {
                        echo '<script>window.location.href="continue/signup.php?url='.strip_tags($_GET['redirect']).'&clientId='.strip_tags($_GET['clientId']).'&name='.strip_tags($results['name']).'#hasPassword";</script>';

        }else{
            header("Location:".$redirect);
        }
        }
}