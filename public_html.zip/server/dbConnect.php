<?php
//$db = mysqli_connect("localhost","id10915029_wp_f8b9176e983ca16a9abbe2dc01f24af7","lXreyj)VjxV7u(q=","id10915029_wp_f8b9176e983ca16a9abbe2dc01f24af7");
$db = mysqli_connect("localhost","root","","k-auth");
?>